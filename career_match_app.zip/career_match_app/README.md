# JHU Career‑Match (Streamlit Demo)

Upload a CV, get matching jobs, and auto‑generate application materials (cover letter + intro email).

## Quickstart (local)

```bash
pip install -r requirements.txt
streamlit run career_match_app.py
```

## Deploy to Streamlit Cloud

1. Push this folder to a GitHub repo.
2. Go to https://share.streamlit.io → *New app*.
3. Enter:
   * **Repository**: `your‑username/repo-name`
   * **Branch**: `main`
   * **Main file**: `career_match_app.py`
4. Click **Deploy**.